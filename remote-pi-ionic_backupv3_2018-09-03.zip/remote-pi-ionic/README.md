# remote-pi-ionic
Remote PI front end app 
